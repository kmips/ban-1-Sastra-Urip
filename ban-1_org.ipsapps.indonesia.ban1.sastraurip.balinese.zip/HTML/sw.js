/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

importScripts("https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js");

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "01-JON-000.html",
    "revision": "a8c60f608cabb50921bf42b52f66c9c5"
  },
  {
    "url": "01-JON-001.html",
    "revision": "cdeb8c03ae39fb070bf6f58db5a4e2e7"
  },
  {
    "url": "01-JON-002.html",
    "revision": "24d4faa4da3976bc72504a652397411c"
  },
  {
    "url": "01-JON-003.html",
    "revision": "2c578d4bf5032c33344f3672b9bca5a7"
  },
  {
    "url": "01-JON-004.html",
    "revision": "615bb59f6c06846db5a19a1100fa7216"
  },
  {
    "url": "02-LUK-001.html",
    "revision": "ea647e15d94b978f7197a295a79e201d"
  },
  {
    "url": "02-LUK-002.html",
    "revision": "a2fab9b7c83924ceca389cfc639d16c4"
  },
  {
    "url": "02-LUK-003.html",
    "revision": "c0ac848e0514e971ab9d5b83461a3b34"
  },
  {
    "url": "02-LUK-004.html",
    "revision": "2c6732a789c7d590ffd952f6e4acda68"
  },
  {
    "url": "02-LUK-005.html",
    "revision": "01853245c2aae2800cec4d7d3da5005b"
  },
  {
    "url": "02-LUK-006.html",
    "revision": "89ef6ed642d411b1bef5e8257fe1cf5e"
  },
  {
    "url": "02-LUK-007.html",
    "revision": "e023b8410dee3dffe018ce8fbabbc95c"
  },
  {
    "url": "02-LUK-008.html",
    "revision": "c536821fd78f7480e192aab69c522e31"
  },
  {
    "url": "02-LUK-009.html",
    "revision": "e219bcd001a963fa4a151c72b88bf0f7"
  },
  {
    "url": "02-LUK-010.html",
    "revision": "1872efcb5a03ca8e85687fa21464183e"
  },
  {
    "url": "02-LUK-011.html",
    "revision": "f550d824661f9abc3f1d089831f1eed5"
  },
  {
    "url": "02-LUK-012.html",
    "revision": "fffd1ccaf0a541512ef9c8e76e523b58"
  },
  {
    "url": "02-LUK-013.html",
    "revision": "a338608fa9d52e01bc6f5364a057cd1d"
  },
  {
    "url": "02-LUK-014.html",
    "revision": "4204f4f473da14981c900f62c3ea800d"
  },
  {
    "url": "02-LUK-015.html",
    "revision": "c03cba4cf9ccddd83e7c6cd2ca378223"
  },
  {
    "url": "02-LUK-016.html",
    "revision": "e383c63e85c91f51ed7585a0749a3bd0"
  },
  {
    "url": "02-LUK-017.html",
    "revision": "f38f4ab22d9ce7c742736655c492e557"
  },
  {
    "url": "02-LUK-018.html",
    "revision": "05e66d67bd9a5f4cde6f7165fb343934"
  },
  {
    "url": "02-LUK-019.html",
    "revision": "3f092cd221b6b25fc9d58eef421204bb"
  },
  {
    "url": "02-LUK-020.html",
    "revision": "eb65ec68f45fe4c05eb3045184f1f01f"
  },
  {
    "url": "02-LUK-021.html",
    "revision": "72c6a5463f118e21939d90224b7df70f"
  },
  {
    "url": "02-LUK-022.html",
    "revision": "8ee8fca817b7d532f1f4f225b59e906b"
  },
  {
    "url": "02-LUK-023.html",
    "revision": "94a398d19aad1b4812073d7750d58a64"
  },
  {
    "url": "02-LUK-024.html",
    "revision": "7092880f3d39d6c31a9e56cca356a4d4"
  },
  {
    "url": "03-GLO-000.html",
    "revision": "d0db002273bb309b3eb6c1d10516fcab"
  },
  {
    "url": "contents/contents-menu-1.html",
    "revision": "67f963e50f9c88d0d4251d21aaba7cc7"
  },
  {
    "url": "contents/fonts/CharisSILCompact-B.ttf",
    "revision": "9cd85723a282d28259b6697699e1f187"
  },
  {
    "url": "contents/fonts/CharisSILCompact-R.ttf",
    "revision": "bf3b8fa39cbdb09e1ef881c5e94fe98c"
  },
  {
    "url": "css/sab-stylesheet.css",
    "revision": "60b39f0172037b10f0cbcd09c2178fcd"
  },
  {
    "url": "css/tooltipster.css",
    "revision": "3380d1b08264fc854bf34db6980d7f4f"
  },
  {
    "url": "fonts/CharisSILCompact-B.ttf",
    "revision": "9cd85723a282d28259b6697699e1f187"
  },
  {
    "url": "fonts/CharisSILCompact-R.ttf",
    "revision": "bf3b8fa39cbdb09e1ef881c5e94fe98c"
  },
  {
    "url": "icons/favicon.ico",
    "revision": "88b9f5ed883e665fb548f6bef0edf720"
  },
  {
    "url": "icons/icon-128.png",
    "revision": "3d7f731a6d0a10b0e9d149860651b608"
  },
  {
    "url": "icons/icon-144.png",
    "revision": "3f5f6c24a14b68d672df897440a0b6dc"
  },
  {
    "url": "icons/icon-152.png",
    "revision": "22b0cd87e230e4e7540de2e59e8ca31d"
  },
  {
    "url": "icons/icon-192.png",
    "revision": "1499a3bf273f10064dbda1eeee5924e5"
  },
  {
    "url": "icons/icon-384.png",
    "revision": "9c814261607c0faa6705ba3c0e3f6070"
  },
  {
    "url": "icons/icon-512.png",
    "revision": "2252f7173b3dc1bd8e308deee59d242a"
  },
  {
    "url": "icons/icon-72.png",
    "revision": "2f3a2d2d86f4b9689bac5e4ca8781454"
  },
  {
    "url": "icons/icon-96.png",
    "revision": "39eb7a1523f0afe52b4f3a9f5992a4de"
  },
  {
    "url": "icons/icon.icns",
    "revision": "e7960d9ae69d80eb0bb3255e6b6c4452"
  },
  {
    "url": "icons/icon.ico",
    "revision": "4c4284876ab920383566acc85b0b9fe4"
  },
  {
    "url": "icons/icon.png",
    "revision": "e7960d9ae69d80eb0bb3255e6b6c4452"
  },
  {
    "url": "icons/touch-icon-ipad-retina.png",
    "revision": "2af232b4ea861e8f13382d839b1e8f29"
  },
  {
    "url": "icons/touch-icon-ipad.png",
    "revision": "22b0cd87e230e4e7540de2e59e8ca31d"
  },
  {
    "url": "icons/touch-icon-iphone-retina.png",
    "revision": "b2cbc1d8f1a7929b683cddc5ce6c9d22"
  },
  {
    "url": "icons/touch-icon-iphone.png",
    "revision": "1c4a4384f8705ba796352dd4f5309875"
  },
  {
    "url": "images/Jonah_small.png",
    "revision": "2cf0f6137da4a4df6c31bafdeebdf524"
  },
  {
    "url": "images/Lukas 6_17_small.png",
    "revision": "e1880ff78c4fb295b737513f372e7145"
  },
  {
    "url": "index.htm",
    "revision": "ea647e15d94b978f7197a295a79e201d"
  },
  {
    "url": "index.html",
    "revision": "79ebb48c43d16f8e05e8f9df8022d8ce"
  },
  {
    "url": "js/app-builder-audio.js",
    "revision": "4276fca4987ba8ea3717127870f4f44c"
  },
  {
    "url": "js/app-builder-footnotes.js",
    "revision": "134b708bb7c8978cdf0bf1a63049583e"
  },
  {
    "url": "js/app-builder-menus.js",
    "revision": "38119c3a390e610aec209609bf30ccfc"
  },
  {
    "url": "js/app-builder-video.js",
    "revision": "efaf04fe4d2c635684b273e3d049171b"
  },
  {
    "url": "js/book-names.js",
    "revision": "81d83c540cb9cc7d5a85a75d47804261"
  },
  {
    "url": "js/jquery-1.11.3.min.js",
    "revision": "895323ed2f7258af4fae2c738c8aea49"
  },
  {
    "url": "js/jquery.tooltipster.min.js",
    "revision": "ff2f685494b400ea2098c79332759a8f"
  },
  {
    "url": "js/popcorn-complete.min.js",
    "revision": "8fbddc624a2f69a176b927a73ad2703d"
  },
  {
    "url": "pwa-main.js",
    "revision": "5630f3086d52ca5e1d63cc6462fcce3d"
  },
  {
    "url": "workbox-config.js",
    "revision": "e12be54ac5dd20622c8e308654daa654"
  }
].concat(self.__precacheManifest || []);
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});
